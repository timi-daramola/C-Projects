#include <iostream>
#include <cmath>
#include<iomanip>

using namespace std;

int main()
{
    float weight, height, BMI, weight_calc, height_calc, result;
    int kilogram = 1;
    int pounds = 2;
    int user_value;
    string Status;
    string under_weight = "Underweight";
    string over_weight = "Overweight";
    string normal_weight = "Normal";
    string obese_weight = "Obese";

    cout <<"BMI Calculator\n" << endl;
    cout <<"1. Weight in Kilogram, height in Meters"<< endl;
    cout <<"2. Weight in Pounds, height in inches\n"<< endl;
    cout <<"Choice: ";
    cin >>user_value;
    while (user_value != kilogram and user_value !=pounds){
        cout <<"\nInvalid choice! Please enter valid choice: ";
        cin >> user_value;}
        if (user_value == kilogram){
                cout <<"\nWeight in Kilogram?: ";
                cin >> weight;
                cout <<"\nHeight in meters?: ";
                cin >> height;
                height_calc = height * height;
                BMI = (weight / height_calc);

                cout <<"\n\nResult..............\n"<< endl;
                cout <<"Weight:\t\t"<<weight<<" pounds"<< endl;
                cout <<"Height:\t\t"<<height<<" inches"<<endl;
                cout <<"BMI:\t\t"<<showpoint<<setprecision(3)<<BMI<< endl;

                if (BMI <18.5)
                    {
                        Status = under_weight;
                    }
                else if(BMI >24 and BMI <30)
                    {
                        Status = over_weight;
                    }
                else if (BMI >=18.5 and BMI <25)
                    {
                        Status = normal_weight;
                    }
                else{
                        Status = obese_weight;
                    }
                cout <<"Status:\t\t"<<Status<< endl;
            }
        else if(user_value == pounds){
                cout <<"\nWeight in pounds?: ";
                cin >> weight;
                cout <<"\nHeight in inches?: ";
                cin >> height;
                height_calc = height * height;
                BMI = (weight / height_calc) * 703;

                cout <<"\n\nResult..............\n"<< endl;
                cout <<"Weight:\t\t"<<weight<<" pounds"<< endl;
                cout <<"Height:\t\t"<<height<<" inches"<<endl;
                cout <<"BMI:\t\t"<<showpoint<<setprecision(3)<<BMI<< endl;

                if (BMI <18.5)
                    {
                        Status = under_weight;
                    }
                else if(BMI >24 and BMI <30)
                    {
                        Status = over_weight;
                    }
                else if (BMI >=18.5 and BMI <25)
                    {
                        Status = normal_weight;
                    }
                else{
                        Status = obese_weight;
                    }
                cout <<"Status:\t\t"<<Status<< endl;

        }
    return 0;

}

